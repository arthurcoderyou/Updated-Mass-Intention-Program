<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timeline for PDF</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        /* Timeline container */
        .timeline {
            position: relative;
            max-width: 100%;
            margin: 3px 0;
        }



        /* Individual timeline container */
        .timeline-item {
            padding: 3px 3px;
            position: relative;
            background-color: inherit;
            width: 100%;
        }


        /* Timeline content */
        .timeline-item-content {
            padding: 3px;
            background-color: white;
            position: relative;
            border-radius: 6px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Date text */
        .timeline-item .date {
            color: #007bff;
            font-weight: bold;
            font-size: 14px;
            margin-bottom: 5px;
        }

        /* Timeline title */
        .timeline-item h3 {
            margin: 0;
            font-size: 18px;
            color: #333;
        }

        /* Timeline description */
        .timeline-item p {
            margin-top: 5px;
            font-size: 14px;
            color: #555;
            text-align: justify;
        }


    </style>
</head>
<body>

<div class="timeline">

    <!-- Timeline Item 1 -->
    <div class="timeline-item">
        <div class="timeline-item-content">
            <h3>Agatacathedral Mass Intentions Report</h3>
            <p>Sunday 10/06/2024</p>
        </div>
    </div>

    <!-- Timeline Item 1 -->
    <div class="timeline-item">

        <div class="timeline-item-content">
            <span class="date">5:00 AM<</span>
        </div>

        <div class="timeline-item-content">
            <h3>Project Kickoff</h3>
            <p>The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
            </p>
        </div>

        <div class="timeline-item-content">
            <h3>Project Kickoff</h3>
            <p>The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
            </p>
        </div>


        <div class="timeline-item-content">
            <h3>Project Kickoff</h3>
            <p>The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
            </p>
        </div>


    </div>

    <!-- Timeline Item 2 -->
    <div class="timeline-item ">
        <div class="timeline-item-content">
            <span class="date">February 15, 2023</span>
            <h3>Initial Planning</h3>
            <p>The team completed the initial project planning phase, outlining key tasks and milestones.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.

                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.

            </p>
        </div>
    </div>

    <!-- Timeline Item 3 -->
    <div class="timeline-item">
        <div class="timeline-item-content">
            <span class="date">March 22, 2023</span>
            <h3>Development Phase Begins</h3>
            <p>The team began working on the core functionality of the project.</p>
        </div>
    </div>

    <!-- Timeline Item 4 -->
    <div class="timeline-item ">
        <div class="timeline-item-content">
            <span class="date">May 10, 2023</span>
            <h3>First Milestone Achieved</h3>
            <p>The first milestone of the project was successfully completed, with core modules developed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
            </p>
        </div>
    </div>

    <!-- Timeline Item 5 -->
    <div class="timeline-item">
        <div class="timeline-item-content">
            <span class="date">July 5, 2023</span>
            <h3>Testing Phase</h3>
            <p>The project entered the testing phase to identify bugs and ensure all functionality works as intended.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.

                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
            </p>
        </div>
    </div>


    <!-- Timeline Item 1 -->
    <div class="timeline-item">
        <div class="timeline-item-content">
            <span class="date">January 1, 2023</span>
            <h3>Project Kickoff</h3>
            <p>The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.</p>
        </div>
    </div>

    <!-- Timeline Item 2 -->
    <div class="timeline-item ">
        <div class="timeline-item-content">
            <span class="date">February 15, 2023</span>
            <h3>Initial Planning</h3>
            <p>The team completed the initial project planning phase, outlining key tasks and milestones.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.

                The project started with a kickoff meeting, where all stakeholders were introduced, and goals were discussed.
            </p>
        </div>
    </div>

    <!-- Timeline Item 3 -->
    <div class="timeline-item">
        <div class="timeline-item-content">
            <span class="date">March 22, 2023</span>
            <h3>Development Phase Begins</h3>
            <p>The team began working on the core functionality of the project.</p>
        </div>
    </div>

    <!-- Timeline Item 4 -->
    <div class="timeline-item ">
        <div class="timeline-item-content">
            <span class="date">May 10, 2023</span>
            <h3>First Milestone Achieved</h3>
            <p>The first milestone of the project was successfully completed, with core modules developed.</p>
        </div>
    </div>

    <!-- Timeline Item 5 -->
    <div class="timeline-item">
        <div class="timeline-item-content">
            <span class="date">July 5, 2023</span>
            <h3>Testing Phase</h3>
            <p>The project entered the testing phase to identify bugs and ensure all functionality works as intended.</p>
        </div>
    </div>

</div>

</body>
</html>


     


<?php /**PATH C:\xampp\htdocs\laravel.aganacathedral.guahan.com\resources\views\report\report_v2.blade.php ENDPATH**/ ?>
<!-- Table Section -->
<div class="max-w-full px-4 py-6 sm:px-6  mx-auto   ">
    <!-- Card -->
    <div class="flex flex-col">
      <div class="-m-1.5 overflow-x-auto">
        <div class="p-1.5 min-w-full inline-block align-middle">
          <div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden dark:bg-neutral-900 dark:border-neutral-700">
            <!-- Header -->
            <div class="px-6 py-4 grid gap-3 md:flex md:justify-between md:items-center border-b border-gray-200 dark:border-neutral-700">
              <div>
                <h2 class="text-xl font-semibold text-black dark:text-neutral-200">
                  Activity Logs
                </h2>
                <p class="text-sm text-black dark:text-neutral-400">
                  Listing of Activity Logs
                </p>
              </div>

              <div>
                <div class="inline-flex gap-x-2">
                  


                  <div class="max-w-sm space-y-3">

                    <input type="text" wire:model.live="search"
                    class="py-3 px-4 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600"
                    placeholder="Search">


                </div>

                <div class="max-w-sm space-y-3">

                    <select wire:model.live="sort_by"
                    class="py-3 px-4 pe-9 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                        <option selected="">Sort by</option>
                        <option value="log_action_asc">Log Action Ascending</option>
                        <option value="log_action_desc">Log Action Descending</option>
                        <option value="log_user_asc">Log User Ascending</option>
                        <option value="log_user_desc">Log User Descending</option>
                        <option value="created_asc">Latest Created</option>
                        <option value="created_desc">Oldest Created</option>
                    </select>


                </div>

                <div class="max-w-24 w-auto space-y-3">

                    <select wire:model.live="record_count"
                    class="py-3 px-4 pe-9 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600">
                        <option selected value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                        <option value="200">200</option>
                        <option value="500">500</option>
                    </select>


                </div>


                  
                </div>
              </div>
            </div>
            <!-- End Header -->

            <!-- Table -->
            <table class="min-w-full divide-y divide-gray-200 dark:divide-neutral-700 ">
              <thead class="bg-gray-50 divide-y divide-gray-200 dark:bg-neutral-800 dark:divide-neutral-700">
                <tr>
                  <th scope="col" class="px-6 py-3 text-start border-s border-gray-200 dark:border-neutral-700">
                    <span class="text-xs font-semibold uppercase tracking-wide text-black dark:text-neutral-200">
                      Log
                    </span>
                  </th>

                  <th scope="col" class="px-6 py-3 text-start border-s border-gray-200 dark:border-neutral-700">
                    <span class="text-xs font-semibold uppercase tracking-wide text-black dark:text-neutral-200">
                      User
                    </span>
                  </th>


                  <th scope="col" class="px-6 py-3 text-end border-s border-gray-200 dark:border-neutral-700">
                    <span class="text-xs font-semibold uppercase tracking-wide text-black dark:text-neutral-200">
                      Date Created
                    </span>
                  </th>
                </tr>
              </thead>

              <tbody class="divide-y divide-gray-200 dark:divide-neutral-700">
                <?php if(!empty($logs) && count($logs) > 0): ?>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <td class="h-px w-auto whitespace-nowrap">
                                <div class="px-6 py-2">
                                    <span class="text-sm text-black dark:text-neutral-200"><?php echo e($log->log_action); ?></span>
                                </div>
                            </td>

                            <td class="h-px w-auto whitespace-nowrap">
                                <div class="px-6 py-2">
                                    <span class="text-sm text-black dark:text-neutral-200"><?php echo e($log->log_user); ?></span>
                                </div>
                            </td>

                            <td class="h-px w-auto whitespace-nowrap">
                                <div class="px-6 py-2">
                                    <span class="text-sm text-black dark:text-neutral-200"><?php echo e($log->created_at->format('M d, Y H:i A')); ?></span>
                                </div>
                            </td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td class="h-px w-auto whitespace-nowrap" colspan="3">
                            <div class="px-6 py-2">
                                <span class="text-sm text-black dark:text-neutral-200">No records found</span>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
              </tbody>
            </table>
            <!-- End Table -->

            <!-- Footer -->
            <div class="px-6 py-4 grid gap-3 md:flex md:justify-between md:items-center border-t border-gray-200 dark:border-neutral-700">

              <?php echo e($logs->links()); ?>

            </div>
            <!-- End Footer -->
          </div>
        </div>
      </div>
    </div>
    <!-- End Card -->
  </div>
  <!-- End Table Section --><?php /**PATH C:\xampp\htdocs\laravel.aganacathedral.guahan.com\resources\views\livewire\admin\activity-logs\activity-log-list.blade.php ENDPATH**/ ?>
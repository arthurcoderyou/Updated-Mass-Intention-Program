




<!-- add icon link -->
<img src="<?php echo e(asset('assets/img/logo.png')); ?>"  width="116" height="100"  alt="Church logo">
<?php /**PATH C:\xampp\htdocs\laravel.aganacathedral.guahan.com\resources\views\components\application-logo.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <!-- add icon link -->
        <link rel="icon" href="<?php echo e(asset('assets/img/logo.png')); ?>"
            type="image/x-icon" />

        <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">

        <style>








        </style>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100 dark:bg-gray-900">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('layout.navigation', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-885035175-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white dark:bg-gray-800 shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>

        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('layout.footer', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-885035175-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <!--scripts -->
        <?php if(session('success')): ?>
            <script>


                Swal.fire({
                    position: "top-end",
                    icon: "success",
                    // title: "Your work has been saved",
                    text: '<?php echo e(session('success')); ?>',
                    showConfirmButton: false,
                    timer: 3000
                });
            </script>
        <?php endif; ?>


        <script>
            document.addEventListener('DOMContentLoaded', function () {
                let pdfUrl = <?php echo json_encode(session('pdf_url'), 15, 512) ?>;  // Retrieve the session PDF URL
                if (pdfUrl) {
                    window.open(pdfUrl, '_blank');  // Open the PDF in a new tab
                    <?php session()->forget('pdf_url'); ?>  // Clear the session after use
                }
            });
        </script>

        

        <!-- end of scripts-->
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel.aganacathedral.guahan.com\resources\views/layouts/app.blade.php ENDPATH**/ ?>
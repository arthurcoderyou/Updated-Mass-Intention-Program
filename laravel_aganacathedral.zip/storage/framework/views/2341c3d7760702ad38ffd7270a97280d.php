<!-- ========== FOOTER ========== -->
<footer class="mt-auto bg-customBlue w-full dark:bg-neutral-950">
    <div class="mt-auto w-full max-w-[85rem] py-10 px-4  mx-auto">


        <div class=" ">
            <div class="flex justify-between items-center">
                <p class="text-sm text-white">
                    © <?php echo e(date('Y')); ?> Agana Cathedral
                </p>
            </div>
            <!-- End Col -->

        </div>
    </div>
</footer>
<!-- ========== END FOOTER ========== -->
<?php /**PATH C:\xampp\htdocs\laravel.aganacathedral.guahan.com\resources\views/livewire/layout/footer.blade.php ENDPATH**/ ?>
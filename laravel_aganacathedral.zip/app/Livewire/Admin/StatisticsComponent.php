<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class StatisticsComponent extends Component
{
    public function render()
    {
        return view('livewire.admin.statistics-component');
    }
}
